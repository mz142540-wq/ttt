REM @echo off

tasklist | findstr /i starcRaft.exe
if "%ERRORLEVEL%"=="0" (
echo exist
taskkill /f /im "starcraft.exe"
)

tasklist | findstr /i tidyLauncher.exe
if "%ERRORLEVEL%"=="0" (
echo exist
taskkill /f /im TidyLauncher.exe
)

set "%ERRORLEVEL%"=="0"