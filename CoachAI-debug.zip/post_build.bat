@echo off
E:\shared\starcraft\bwapi-data\TidyLauncher\TidyLauncher.exe