#include "draw.h"
#include <cmath>

#include "offsets.h"
#include "memory.h"
#include <vector>
#include "yms.h"

std::atomic<uintptr_t> draw_counter;
bool all_visions;
int frame_skip_ms = 0;
uint32_t fastForwardStartFrames = 0;
uint32_t fastForwardEndFrames = 0;
int fastForwardProgressCount = 0;
bool isFastForwarding = false;
uint32_t last_frame_skip_tick = 0;

class drawhook
{
    public:
        drawhook(void (*f)(uint8_t *, xuint, yuint), int p) { func = f; priority = p; }
        bool operator<(const drawhook &other) const { return priority < other.priority; }

        void (*func)(uint8_t *, xuint, yuint);
        int priority;
};
std::vector<drawhook> draw_hooks;

#include "console/windows_wrap.h"

uint8_t fake_screenbuf[resolution::screen_width * resolution::screen_height];

// As sc only draws the parts of screen marked dirty,
// this adds an additional buffer to which has the original
// image without any of the draw hook additions.
// So the draw hooks do not have to mark areas dirty or
// anything, but it also makes drawing a lot slower.
uint8_t fake_screenbuf_2[resolution::screen_width * resolution::screen_height];


void DrawScreen()
{
    if (fastForwardEndFrames > 0) {
        bool draw = false;

        // Start ff
        if (fastForwardEndFrames > 0 && !isFastForwarding)
        {
            fastForwardProgressCount = 0;
            isFastForwarding = true;
            bw::game_speed_waits[*bw::game_speed] = 0;
            draw = true;
        }
        // Draw game every 5% while in fast forward mode
        int duration = fastForwardEndFrames - fastForwardStartFrames;
        int part = *bw::frame_count - fastForwardStartFrames;
        int progress = std::roundf(((float)part / (float)duration) * 100);
        if (progress % 5 == 0 && fastForwardProgressCount < progress) {
            fastForwardProgressCount = progress;
            draw = true;
        }

        // End of ff
        if (isFastForwarding && *bw::frame_count > fastForwardEndFrames)
        {
            isFastForwarding = false;
            draw = true;
        }

        if (!draw)
            return;
    }

    const auto relaxed = std::memory_order_relaxed;
    // Overflowing is fine
    draw_counter.store(draw_counter.load(relaxed) + 1, relaxed);
    if (frame_skip_ms != 0)
    {
        uint32_t tick = GetTickCount();
        if (tick < last_frame_skip_tick + frame_skip_ms) {
            return;
        }
        last_frame_skip_tick = tick;
    }

    // The load screen code likes to draw screen after every grp loaded,
    // and this function is a lot slower than the original one
    if (*bw::load_screen != nullptr)
    {
        static bool drawn_load_screen_once;
        if (drawn_load_screen_once)
            return;
        drawn_load_screen_once = true;
    }
    Surface *game_screen = &*bw::game_screen;
    if (!game_screen->image)
        return;
    *bw::current_canvas = game_screen;
    if (*bw::no_draw)
    {
        memset(game_screen->image, 0, game_screen->w * game_screen->h);
        Rect32 area(0, 0, resolution::screen_width, resolution::screen_height);
        bw::CopyToFrameBuffer(&area);
    }
    else
    {
        DrawParam param;
        for (int i = 7; i >= 0; i--)
        {
            DrawLayer *layer = &(bw::draw_layers[i]);
            if (!layer->draw)
                continue;
            if (!(layer->flags & 0x21))
            {
                if (bw::ContainsDirtyArea(layer->area.left, layer->area.top, layer->area.left + layer->area.right, layer->area.top + layer->area.bottom))
                    layer->flags |= 0x4;
                else if (~layer->flags & 0x2)
                    continue;
            }
            param.area = Rect16(0 - layer->area.left, 0 - layer->area.top, -1 - layer->area.left + resolution::screen_width, -1 - layer->area.top + resolution::screen_height);
            param.w = resolution::screen_width;
            param.h = resolution::screen_height;
            (*layer->Draw)(0, 0, layer->func_param, &param);
            layer->flags &= ~0x7;
        }
    }

    if (*bw::trans_list && *bw::game_screen_redraw_trans)
    {
        // Ew...
        bw::STransBind(*bw::game_screen_redraw_trans);
        bw::STrans437(*bw::trans_list, &bw::screen_redraw_tiles[0], 3, &*bw::game_screen_redraw_trans);
        bw::CopyGameScreenToFramebuf();
        std::fill(bw::screen_redraw_tiles.begin(), bw::screen_redraw_tiles.end(), 0);
    }

    memcpy(fake_screenbuf_2, fake_screenbuf, resolution::screen_width * resolution::screen_height);
    for (drawhook &hook : draw_hooks)
    {
        (*hook.func)(fake_screenbuf_2, resolution::screen_width, resolution::screen_height);
    }
    uint8_t *surface;
    int width;
    if ((*bw::SDrawLockSurface_Import)(0, 0, &surface, &width, 0))
    {
        for (unsigned int  i = 0; i < resolution::screen_height; i++)
            memcpy(surface + i * width, fake_screenbuf_2 + i * resolution::screen_width, resolution::screen_width);
        (*bw::SDrawUnlockSurface_Import)(0, surface, 0, 0);
    }

    *bw::current_canvas = nullptr;
}

int SDrawLockSurface_Hook(int surface_id, Rect32 *a2, uint8_t **surface, int *width, int unused)
{
    if (surface_id == 0)
    {
        *surface = fake_screenbuf;
        *width = resolution::screen_width;
        return 1;
    }
    else
    {
        return (*bw::SDrawLockSurface_Import)(surface_id, a2, surface, width, unused);
    }
}

int SDrawUnlockSurface_Hook(int surface_id, uint8_t *surface, int a3, int a4)
{
    if (surface == fake_screenbuf)
        return 1;

    return (*bw::SDrawUnlockSurface_Import)(surface_id, surface, a3, a4);
}

void GenerateFog()
{
    int screen_x = *bw::screen_pos_x_tiles;
    if (screen_x != 0)
        screen_x--;
    int screen_y = *bw::screen_pos_y_tiles;
    if (screen_y != 0)
        screen_y--;
    uint32_t *flags = (*bw::map_tile_flags) + screen_y * *bw::map_width_tiles + screen_x;
    uint32_t *orig_flags = flags;
    uint8_t *pos = *bw::fog_arr1;
    int shown_value = *bw::fog_variance_amount;
    int fow_value = shown_value / 2;

    int y_pos = screen_y;
    for (int i = 0; i < 0x11; i++)
    {
        int x_pos = *bw::screen_pos_x_tiles - 1;
        flags = orig_flags;
        for (int i = 0; i < 0x18; i++)
        {
            // Obviously people can just remove multiplayer check if they wish
            // Bw had nice vision-based sync but it does not work with dynamically allocated sprites
            if (all_visions && !IsMultiplayer())
            {
                if ((0xff00 & flags[0]) == 0xff00)
                    *pos = 0;
                else if ((0xff & flags[0]) == 0xff)
                    *pos = fow_value;
                else
                    *pos = shown_value;
            }
            else if (IsReplay())
            {
                if (*bw::replay_show_whole_map)
                    *pos = shown_value;
                else if (!((*bw::replay_visions << 8) & ~flags[0]))
                    *pos = 0;
                else if (!(*bw::replay_visions & ~flags[0]))
                    *pos = fow_value;
                else
                    *pos = shown_value;
            }
            else
            {
                if (*bw::player_exploration_visions & flags[0])
                    *pos = 0;
                else if (*bw::player_visions & flags[0])
                    *pos = fow_value;
                else
                    *pos = shown_value;
            }
            if (x_pos < *bw::map_width_tiles - 1 && x_pos >= 0)
                flags++;
            x_pos++;
            pos++;
        }
        if (y_pos < *bw::map_height_tiles - 1 && y_pos >= 0)
            orig_flags += *bw::map_width_tiles;
        y_pos++;
    }

    // Blend fog
    // Screen is 0x18 x 0x11 tiles
    // Well every border has 1 nonvisible tile, it is only used for blending?
    pos = *bw::fog_arr1 + 0x18 + 0x1;
    uint8_t *out = *bw::fog_arr2 + 0x18 + 0x1;
    for (int i = 0; i < 0x11 - 2; i++)
    {
        for (int i = 0; i < 0x18 - 2; i++)
        {
            int val = pos[0] * 2;
            val = (val + pos[-1] + pos[1] + pos[-0x18] + pos[0x18]) * 2;
            val = (val + pos[-0x17] + pos[0x17] + pos[-0x19] + pos[0x19]) / 16;
            *out = val;
            pos++;
            out++;
        }
        pos += 2;
        out += 2;
    }
}

void AddDrawHook(void (*func)(uint8_t *, xuint, yuint), int priority)
{
    drawhook hook(func, priority);
    auto it = lower_bound(draw_hooks.begin(), draw_hooks.end(), hook);
    draw_hooks.insert(it, hook);
}
