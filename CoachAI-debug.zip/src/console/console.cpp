#include "console.h"

#include "../resolution.h"
#include "../patch/patchmanager.h"

#include <string.h>
#include <windows.h>
#undef DrawText // nyyh
#include <ctime>
#include <algorithm>

using std::string;
using std::move;

namespace Common {

    Console* console = nullptr;

    Line::Line(const std::string& str_, int type_, unsigned char hlines) : str(str_), type(type_)
    {
        horizontal_lines = hlines;
    }

    LineIterator::LineIterator()
    {
        h_line = 0;
    }

    LineIterator::LineIterator(LogContainer::iterator base)
    {
        h_line = 0;
        it = base;
    }

    void LineIterator::operator++()
    {
        if (++h_line >= it->horizontal_lines)
        {
            ++it;
            h_line = 0;
        }
    }

    void LineIterator::operator--()
    {
        if (h_line == 0)
        {
            --it;
            h_line = it->horizontal_lines - 1;
        }
        else
            --h_line;
    }

    Line& LineIterator::operator *()
    {
        return *it;
    }

    LineIterator& LineIterator::operator=(LogContainer::iterator it_)
    {
        it = it_;
        return *this;
    }

    typedef LRESULT(CALLBACK WndProc)(HWND, UINT, WPARAM, LPARAM);
    static WndProc* OldWndProc;
    static HWND console_hwnd = NULL;
    LRESULT CALLBACK ConsoleWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
    {
        if (console)
        {
            switch (msg)
            {
            case WM_CHAR:
                if (console->CharHook(wparam))
                    return 0;
                break;
            case WM_KEYDOWN:
                if (console->KeyHook(wparam, (lparam >> 16) & 0xff))
                    return 0;
                break;
            }
        }
        return CallWindowProcA(OldWndProc, hwnd, msg, wparam, lparam);
    }

    void Console::HookWndProc(void* hwnd)
    {
        console_hwnd = (HWND)hwnd;
        OldWndProc = (WndProc*)SetWindowLongPtr((HWND)hwnd, GWLP_WNDPROC, (LONG)&ConsoleWndProc);
    }

    void Console::UnhookWndProc()
    {
        if (console_hwnd)
        {
            SetWindowLongPtr(console_hwnd, GWLP_WNDPROC, (LONG)OldWndProc);
            console_hwnd = NULL;
        }
    }

    static int __stdcall TaHook(void* hwnd, void* acctable, MSG* msg)
    {
        if (console && console->TranslateAcceleratorHook(msg))
            return 0;
        return TranslateAccelerator((HWND)hwnd, (HACCEL)acctable, msg);
    }

    void Console::HookTranslateAccelerator(PatchContext* patch, uintptr_t expected_base)
    {
        patch->ImportPatch(expected_base, "user32.dll", "TranslateAcceleratorA", (void*)&TaHook);
    }

    Console::Console()
    {
        pos = { 20, 20 };
        int width = resolution::screen_width - 20 * 2;
        int height = resolution::screen_height / 3 - 20 * 2;
        history_end = height - 18;
        history_lines = (history_end - 3) / 11;
        max_line_len = width - 10;
        history_size = 256;

        colors[Color::own] = Color::Default::own_cmd;
        colors[Color::text] = Color::Default::text;
        colors[Color::typo] = Color::Default::typo;
        colors[Color::fail] = Color::Default::fail;
        colors[Color::bg] = Color::Default::bg;
        colors[Color::border] = Color::Default::border;

        surface.Init(width, height);

        line_pos = lines.begin();

        char actual_path[256];
        ExpandEnvironmentStrings("%systemroot%\\fonts\\lucon.ttf", actual_path, 250);
        font.Load(actual_path, 10, true);
        int prev_error = font.last_error;
        ExpandEnvironmentStrings("%systemroot%\\fonts\\arialuni.ttf", actual_path, 250);
        font.Load(actual_path, 10, true);

        char buf[256];
        sprintf(buf, ":: CoachAI-debug :: by/ Moataz");
        Print(buf);

        ignore_next = false;
        clear = false;
        cursor_pos = 0;  // ← ADD THIS LINE
        if (prev_error && font.last_error)
        {
            MessageBoxA(0, "Fonts could not be loaded", "Console error", 0);
            state = fail;
        }
        else
            state = hidden;
    }

    Console::~Console()
    {
    }

    int Console::CharLength(char c)
    {
        auto chara = font.GetChar(c);
        if (chara)
            return chara.take()->full_width;
        else
            return 0;
    }

    string Console::NextHorizontalLine(const string& line, int pos)
    {
        int length = 0, orig_pos = pos;

        while (42)
        {
            int next_length = 0;
            auto next_space = line.find_first_of("\t\x20\v\f", pos);
            if (next_space == line.npos)
                std::for_each(line.begin() + pos, line.end(), [&](char c) { next_length += CharLength(c); });
            else
                std::for_each(line.begin() + pos, line.begin() + next_space + 1, [&](char c) { next_length += CharLength(c); });

            if (length + next_length > max_line_len)
            {
                if (length == 0)
                {
                    int i = 0;
                    for (char c = line[pos + i]; c != 0; i++)
                    {
                        next_length = CharLength(c);
                        if (length + next_length > max_line_len)
                            break;
                        length += next_length;
                    }
                    return line.substr(pos, i);
                }
                else
                    return line.substr(orig_pos, pos - orig_pos);
            }
            if (next_space == line.npos)
                return line.substr(orig_pos);
            length += next_length;
            pos = next_space + 1;
        }
    }

    string Console::HorizontalLine(const Line& line, int entry, int* pos_hint)
    {
        if (*pos_hint == -1)
        {
            int pos = 0;
            string str;
            while (entry-- >= 0)
            {
                str = NextHorizontalLine(line.str, pos);
                pos += str.length();
            }
            *pos_hint = pos;
            return str;
        }
        else
        {
            string str = NextHorizontalLine(line.str, *pos_hint);
            *pos_hint += str.length();
            return str;
        }
    }

    unsigned int Console::HorizontalLineAmount(const string& line)
    {
        unsigned int pos = 0, count = 0;
        do
        {
            pos += NextHorizontalLine(line, pos).length();
            count++;
        } while (pos < line.length());
        return count;
    }

    void Console::DrawBackground()
    {
        uint8_t* buf = surface.buf;
        int width = surface.width;
        memset(buf, colors[Color::border], width);
        for (int y = 1; y < surface.height - 1; y++)
        {
            buf[y * width] = colors[Color::border];
            memset(buf + y * width + 1, colors[Color::bg], width - 2);
            buf[y * width + width - 1] = colors[Color::border];
        }
        memset(buf + (surface.height - 1) * width, colors[Color::border], width);
        memset(buf + (history_end)*width, colors[Color::border], width);
    }

    void Console::Render()
    {
        static DWORD last_render_time = 0;
        DWORD current_time = GetTickCount();

        // Only update if dirty or render time exceeded
        if (!dirty && (current_time - last_render_time) < 16)  // ~60 FPS
        {
            return;
        }
        last_render_time = current_time;

        DrawBackground();
        int i = 0, pos_hint = -1;
        Point draw_pos(5, 10);
        for (auto it = line_pos; it != lines.end(); ++it)
        {
            if (i >= history_lines)
                break;

            Line& line = *it;
            if (it.HLine() == 0)
                pos_hint = 0;
            string h_line = HorizontalLine(line, it.HLine(), &pos_hint);
            surface.DrawText(&font, h_line, draw_pos, colors[line.type]);
            draw_pos.y += 11;
            i++;
        }
        draw_pos = Point(5, surface.height - 5);

        // Draw command with blinking cursor
        if (state == shown)
        {
            std::string before_cursor = current_cmd.substr(0, cursor_pos);
            std::string after_cursor = cursor_pos < current_cmd.length() ?
                current_cmd.substr(cursor_pos) : "";

            surface.DrawText(&font, before_cursor, draw_pos, colors[Color::own]);

            // Calculate cursor position
            int cursor_x = draw_pos.x;
            for (char c : before_cursor)
                cursor_x += CharLength(c);

            // Blink cursor every 300ms (adjust this value to change blink rate)
            static DWORD blink_start = GetTickCount();
            DWORD blink_elapsed = current_time - blink_start;
            bool blink_visible = (blink_elapsed / 300) & 1;  // 300ms per blink cycle

            if (blink_visible)
                surface.DrawText(&font, "_", Point(cursor_x, draw_pos.y), colors[Color::own]);

            // Draw text after cursor
            surface.DrawText(&font, after_cursor, Point(cursor_x + CharLength('_'), draw_pos.y), colors[Color::own]);
        }
        else
        {
            surface.DrawText(&font, current_cmd, draw_pos, colors[Color::own]);
        }

        dirty = false;
    }

    void Console::Draw(uint8_t* framebuf, int w, int h)
    {
        if (state == hidden)
            return;
        if (w != resolution::screen_width || h != resolution::screen_height)
            return; // vois panic?

        Render();

        for (int y = pos.y, i = 0; y < pos.y + surface.height; y++, i++)
        {
            memcpy(framebuf + y * w + pos.x, surface.buf + i * surface.width, surface.width);
        }
    }

    void Console::Show()
    {
        if (state == fail)
            return;
        state = shown;
    }

    void Console::Hide()
    {
        state = hidden;
    }

    void Console::ClearScreen()
    {
        clear = true;
    }

    void Console::Clear()
    {
        lines.clear();
        line_pos = lines.end();
    }

    int Console::Command(const string& cmd)
    {
        CmdArgs args(cmd.c_str());
        auto func = commands.find(args[0]);
        if (func != commands.end())
        {
            if ((func->second)(args))
                return Color::own;
            else
                return Color::fail;
        }
        return Color::typo;
    }

    void Console::ProcessCommand()
    {
        if (current_cmd.empty())
            return;

        AddCommandToHistory(current_cmd);

        PrintBase(Line(current_cmd, 0, HorizontalLineAmount(current_cmd)));
        Line& cmd_line = *lines.rbegin();
        int color = Command(current_cmd);
        cmd_line.type = color;
        current_cmd.clear();
        cursor_pos = 0;  // ← ADD THIS LINE
        if (clear)
        {
            lines.clear();
            line_pos = lines.end();
            clear = false;
        }
    }

    int Console::CountLinesBetween(const LineIterator& a_, const LineIterator& b)
    {
        auto a = a_;
        int i = 0;
        while (a != b)
        {
            ++i;
            ++a;
        }
        return i;
    }

    void Console::PrintBase(const Line& line)
    {
        dirty = true;
        lines.push_back(line);

        if (line_pos == lines.end())
            --line_pos;
        else if (CountLinesBetween(line_pos, lines.end()) > history_lines)
        {
            int count = line.horizontal_lines;
            while (count--)
                ++line_pos;
        }
        if (lines.size() > history_size)
            lines.pop_front();
    }

    void Console::Print(const std::string& line)
    {
        PrintBase(Line(line, Color::text, HorizontalLineAmount(line)));
    }

    void Console::Printf(const char* format, ...)
    {
        char buf[512];
        va_list varg;
        va_start(varg, format);
        vsnprintf(buf, sizeof buf, format, varg);
        va_end(varg);
        Print(buf);
    }

    bool Console::CharHook(wchar_t chr)
    {
        if (ignore_next)
        {
            ignore_next = false;
            return false;
        }

        if (state != shown)
            return false;

        // Ignore control characters (except backspace, escape, enter)
        if (chr < 32 && chr != 0x8 && chr != 0x1b && chr != 0xd)
            return true;  // ← CONSUME the Ctrl character

        dirty = true;
        switch (chr)
        {
        case 0x8: // Backspace
            if (cursor_pos > 0) {
                current_cmd.erase(cursor_pos - 1, 1);
                cursor_pos--;
            }
            break;
        case 0x1b: // Esc
            current_cmd.clear();
            cursor_pos = 0;
            ResetHistoryNavigation();
            break;
        case 0xd: // Enter
            ProcessCommand();
            break;
        default:
        {
            char buf[8];
            int count = WideCharToMultiByte(CP_UTF8, 0, &chr, 1, buf, sizeof buf, NULL, NULL);
            for (int i = 0; i < count; i++)
                current_cmd.insert(cursor_pos + i, 1, buf[i]);
            cursor_pos += count;
        }
        break;
        }

        return true;
    }

    bool Console::KeyHook(int key, int scan)
    {
        // Check if Ctrl is pressed
        bool ctrl_pressed = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;

        switch (scan)
        {
        case 0x48: // Up
            if (state != shown)
                return false;

            NavigateHistoryUp();
            return true;
            break;
        case 0x50: // Down
            if (state != shown)
                return false;

            NavigateHistoryDown();
            return true;
            break;
        case 0x4B: // Left arrow
            if (state == shown) {
                if (ctrl_pressed) {
                    // Move to start of previous word
                    if (cursor_pos > 0) {
                        cursor_pos--;
                        // Skip whitespace
                        while (cursor_pos > 0 && std::isspace(current_cmd[cursor_pos])) {
                            cursor_pos--;
                        }
                        // Skip word characters
                        while (cursor_pos > 0 && !std::isspace(current_cmd[cursor_pos - 1])) {
                            cursor_pos--;
                        }
                        dirty = true;
                    }
                }
                else {
                    // Move one character left
                    if (cursor_pos > 0) {
                        cursor_pos--;
                        dirty = true;
                    }
                }
                return true;
            }
            break;
        case 0x4D: // Right arrow
            if (state == shown) {
                if (ctrl_pressed) {
                    // Move to start of next word
                    if (cursor_pos < current_cmd.length()) {
                        // Skip current word characters
                        while (cursor_pos < current_cmd.length() && !std::isspace(current_cmd[cursor_pos])) {
                            cursor_pos++;
                        }
                        // Skip whitespace
                        while (cursor_pos < current_cmd.length() && std::isspace(current_cmd[cursor_pos])) {
                            cursor_pos++;
                        }
                        dirty = true;
                    }
                }
                else {
                    // Move one character right
                    if (cursor_pos < current_cmd.length()) {
                        cursor_pos++;
                        dirty = true;
                    }
                }
                return true;
            }
            break;
        case 0x47: // Home
            if (state == shown) {
                if (cursor_pos > 0)
                {
                    cursor_pos = 0;
                    dirty = true;
                }
                return true;
            }
            break;
        case 0x4F: // End
            if (state == shown) {
                if (cursor_pos < current_cmd.length())
                {
                    cursor_pos = current_cmd.length();
                    dirty = true;
                }
                return true;
            }
            break;
        case 0x53: // Delete key - delete character AT cursor
            if (state == shown) {
                if (cursor_pos < current_cmd.length()) {
                    current_cmd.erase(cursor_pos, 1);
                    dirty = true;
                }
                return true;
            }
            break;
        case 0x2F: // V key - Paste
            if (state == shown && ctrl_pressed) {
                PasteFromClipboard();
                return true;
            }
            break;
        case 0x29: // Tilde - toggle console
            if (state == shown) {
                Hide();
                ResetHistoryNavigation();
            }
            else {
                Show();
                ignore_next = true;
            }
            return true;
        }
        return false;
    }

    void Console::PasteFromClipboard()
    {
        if (!OpenClipboard(NULL))
            return;

        HANDLE hClipData = GetClipboardData(CF_TEXT);
        if (!hClipData)
        {
            CloseClipboard();
            return;
        }

        char* text = (char*)GlobalLock(hClipData);
        if (!text)
        {
            CloseClipboard();
            return;
        }

        // Process pasted text
        std::string pasted(text);

        // Remove newlines (keep only single line)
        pasted.erase(std::remove_if(pasted.begin(), pasted.end(),
            [](char c) { return c == '\n' || c == '\r'; }),
            pasted.end());

        // Insert at cursor
        if (current_cmd.length() + pasted.length() <= 512)
        {
            current_cmd.insert(cursor_pos, pasted);
            cursor_pos += pasted.length();
            dirty = true;
        }

        GlobalUnlock(hClipData);
        CloseClipboard();
    }

    void Console::AddCommandToHistory(std::string cmd) {
        // Remove any potential previous occurcances of command in history
        commandsHistory.erase(remove(commandsHistory.begin(), commandsHistory.end(), cmd), commandsHistory.end());
        // Push the new cmd to the end
        commandsHistory.push_back(current_cmd);
        ResetHistoryNavigation();
    }

    void Console::ResetHistoryNavigation() {
        // Set index outside of bounds to exit navigatioh
        commandsHistoryIndex = commandsHistory.size();
    }


    void Console::NavigateHistoryUp() {
        if (commandsHistory.size() == 0) {
            return;
        }
        commandsHistoryIndex--;
        if (commandsHistoryIndex <= 0) {
            commandsHistoryIndex = 0;
        }
        dirty = true;
        current_cmd.clear();
        current_cmd = commandsHistory.at(commandsHistoryIndex);
        cursor_pos = current_cmd.length();  // ← ADD THIS LINE
    }

    void Console::NavigateHistoryDown() {
        if (commandsHistory.size() == 0) {
            return;
        }
        commandsHistoryIndex++;

        // Exit history navigation if out of bounds
        if (commandsHistoryIndex >= commandsHistory.size()) {
            ResetHistoryNavigation();
        }
        dirty = true;
        current_cmd.clear();
        if (commandsHistoryIndex <= commandsHistory.size() - 1) {
            current_cmd = commandsHistory.at(commandsHistoryIndex);
        }
        cursor_pos = current_cmd.length();  // ← ADD THIS LINE
    }

    bool Console::TranslateAcceleratorHook(void* msg_)
    {
        //MSG *msg = (MSG *)msg_;
        if (state == shown)
        {
            return true;
        }
        return false;
    }


} // namespace Console

